﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Domain.Entities
{
   public class Phone
    {
        [HiddenInput(DisplayValue=false)]
        public int PhoneId { get; set; }

        [Display(Name ="Name")]
        [Required(ErrorMessage ="Please,enter phone name")]
        public string Name { get; set; }

        [DataType(DataType.MultilineText)]
        [Display(Name ="Description")]
        [Required(ErrorMessage = "Please,enter phone description")]
        public string Description { get; set; }

        [Display(Name ="Category")]
        [Required(ErrorMessage = "Please,enter category")]
        public string Category { get; set; }

        [Display(Name ="Price(euro)")]
        [Required]
        [Range(0.01,double.MaxValue,ErrorMessage= "Please,enter positive value price")]
        public decimal Price { get; set; }

        public byte[] ImageData { get; set; }
        public string ImageMimeType { get; set; }
    }
}
